'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { ALL_TEMPLATES, type ServiceKey, type Template } from '@/lib/templates';
import LanguageSwitcher from '@/components/ui/LanguageSwitcher';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

const SERVICE_META: Record<
  ServiceKey,
  { icon: string; titleKey: 'images' | 'video' | 'music' | 'code' | 'chat'; color: string; apiReady: boolean }
> = {
  images: { icon: '🖼️', titleKey: 'images', color: 'from-blue-600/20 border-blue-800/40', apiReady: false },
  video: { icon: '🎬', titleKey: 'video', color: 'from-purple-600/20 border-purple-800/40', apiReady: false },
  music: { icon: '🎵', titleKey: 'music', color: 'from-emerald-600/20 border-emerald-800/40', apiReady: false },
  code: { icon: '💻', titleKey: 'code', color: 'from-amber-600/20 border-amber-800/40', apiReady: false },
  chat: { icon: '🤖', titleKey: 'chat', color: 'from-rose-600/20 border-rose-800/40', apiReady: true },
};

type ProviderOpt = {
  slug: string;
  name: string;
  defaultModel: string | null;
  models: string[];
};

export default function ServiceWorkspace({ service }: { service: ServiceKey }) {
  const { lang, t, dir } = useLanguage();
  const meta = SERVICE_META[service];
  const templates = ALL_TEMPLATES[service];
  const [selected, setSelected] = useState<Template | null>(null);
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [creditsLeft, setCreditsLeft] = useState<number | null>(null);
  const [providers, setProviders] = useState<ProviderOpt[]>([]);
  const [provider, setProvider] = useState('');
  const [metaInfo, setMetaInfo] = useState('');

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.email) {
        window.location.href = '/login';
        return;
      }
      setUserEmail(session.user.email);
      try {
        const res = await fetch('/api/user/me', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: session.user.email }),
        });
        const data = await res.json();
        if (typeof data.credits === 'number') setCreditsLeft(data.credits);
      } catch {}

      try {
        const pr = await fetch('/api/providers');
        const pdata = await pr.json();
        const list: ProviderOpt[] = pdata.providers || [];
        setProviders(list);
        if (list.length && !provider) setProvider(list[0].slug);
      } catch {}
    })();
  }, []);

  const pickTemplate = (tpl: Template) => {
    setSelected(tpl);
    setPrompt(lang === 'ar' ? tpl.promptAr : tpl.promptEn);
    setResult('');
    setError('');
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError(lang === 'ar' ? 'اكتب أو اختر قالباً أولاً' : 'Write or pick a template first');
      return;
    }
    setLoading(true);
    setError('');
    setResult('');
    setMetaInfo('');

    if (service === 'chat' || meta.apiReady) {
      try {
        const res = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            tone: lang === 'ar' ? 'احترافي ورسمي' : 'Professional',
            model: provider === 'openai' ? 'GPT-4o Mini' : 'Gemini 1.5 Flash',
            length: lang === 'ar' ? 'متوسط' : 'medium',
            email: userEmail,
            provider: provider || undefined,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Error');
        setResult(data.result);
        if (typeof data.creditsRemaining === 'number') setCreditsLeft(data.creditsRemaining);
        setMetaInfo(
          `${data.provider || provider} · ${data.model || ''}${
            data.usedFallback ? ' · Fallback' : ''
          }`
        );
      } catch (e: any) {
        setError(e.message || 'Failed');
      } finally {
        setLoading(false);
      }
    } else {
      setTimeout(() => {
        setResult(
          lang === 'ar'
            ? `✅ تم استلام الطلب عبر المزود: ${provider || 'تلقائي'}\n\nالخدمة «${t(
                meta.titleKey
              )}» واجهتها جاهزة. ربط التوليد الفعلي قادم.\n\n${prompt}`
            : `✅ Request received via ${provider || 'auto'}\n\nService ready. Live provider soon.\n\n${prompt}`
        );
        setLoading(false);
      }, 600);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100" dir={dir}>
      <header className="border-b border-slate-800 bg-slate-900/80 sticky top-0 z-40 backdrop-blur">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="text-xs text-slate-400 hover:text-white">
              ← {t('back')}
            </Link>
            <span className="text-xl">{meta.icon}</span>
            <h1 className="font-bold text-white text-sm sm:text-base">{t(meta.titleKey)}</h1>
          </div>
          <div className="flex items-center gap-2">
            {creditsLeft !== null && (
              <span className="text-xs text-emerald-400 font-bold px-2 py-1 rounded-lg bg-emerald-950/40 border border-emerald-900/50">
                {creditsLeft} Credit
              </span>
            )}
            <LanguageSwitcher />
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
        {/* اختيار المزود */}
        <section className="rounded-2xl border border-slate-800 bg-slate-900 p-4">
          <label className="block text-xs text-slate-400 mb-2">
            {lang === 'ar' ? 'اختر مزود الذكاء الاصطناعي' : 'Choose AI Provider'}
          </label>
          <div className="flex flex-wrap gap-2">
            {providers.length === 0 ? (
              <span className="text-xs text-slate-500">
                {lang === 'ar' ? 'لا يوجد مزود مفعّل حالياً' : 'No providers available'}
              </span>
            ) : (
              providers.map((p) => (
                <button
                  key={p.slug}
                  type="button"
                  onClick={() => setProvider(p.slug)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold border transition ${
                    provider === p.slug
                      ? 'bg-blue-600 border-blue-500 text-white'
                      : 'bg-slate-950 border-slate-700 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  {p.name}
                </button>
              ))
            )}
          </div>
        </section>

        {/* Templates */}
        <section>
          <h2 className="text-lg font-bold text-white mb-1">{t('chooseTemplate')}</h2>
          <p className="text-slate-500 text-xs mb-4">{t('customizePrompt')}</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {templates.map((tpl) => {
              const active = selected?.id === tpl.id;
              return (
                <button
                  key={tpl.id}
                  type="button"
                  onClick={() => pickTemplate(tpl)}
                  className={`text-right rounded-2xl border p-4 transition-all ${
                    active
                      ? 'border-blue-500 bg-blue-950/40 ring-1 ring-blue-500/40'
                      : 'border-slate-800 bg-slate-900 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-lg">{tpl.icon || '✨'}</span>
                    <span className="font-bold text-white text-sm">
                      {lang === 'ar' ? tpl.titleAr : tpl.titleEn}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-2">
                    {(lang === 'ar' ? tpl.promptAr : tpl.promptEn).slice(0, 80)}…
                  </p>
                </button>
              );
            })}
          </div>
        </section>

        <section className={`rounded-3xl border bg-gradient-to-l ${meta.color} border-slate-800 p-5 sm:p-6 space-y-4`}>
          <label className="block text-xs font-medium text-slate-400">{t('orWriteOwn')}</label>
          <textarea
            rows={5}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={lang === 'ar' ? 'اكتب تفاصيل طلبك هنا...' : 'Write your prompt here...'}
            className="w-full p-4 bg-slate-950 border border-slate-800 rounded-2xl text-white text-sm focus:outline-none focus:border-blue-500 resize-y min-h-[120px]"
          />
          {error && (
            <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-red-400 text-xs">
              {error}
            </div>
          )}
          <button
            onClick={handleGenerate}
            disabled={loading}
            className="w-full sm:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-900 text-white font-bold rounded-xl text-sm transition"
          >
            {loading ? t('generating') : `✨ ${t('generate')}`}
          </button>
        </section>

        <section className="rounded-3xl border border-slate-800 bg-slate-900 p-5 sm:p-6">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-xs font-bold text-slate-400">{t('result')}</h3>
            {metaInfo && <span className="text-[10px] text-slate-500 font-mono">{metaInfo}</span>}
          </div>
          <div className="min-h-[140px] p-4 bg-slate-950 border border-slate-800 rounded-2xl text-slate-300 text-sm whitespace-pre-wrap leading-relaxed">
            {result || (lang === 'ar' ? 'ستظهر النتيجة هنا...' : 'Result will appear here...')}
          </div>
        </section>
      </div>
    </div>
  );
}
