import { NextRequest, NextResponse } from 'next/server';
import { ensureUserByEmail, totalCredits } from '@/lib/credits';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email = (body.email || '').trim().toLowerCase();
    if (!email) {
      return NextResponse.json({ error: 'البريد مطلوب' }, { status: 400 });
    }

    const user = await ensureUserByEmail(email, {
      firstName: body.firstName,
      lastName: body.lastName,
      username: body.username,
    });

    const credits = totalCredits(user.wallet);
    const recentJobs = await prisma.aiJob.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 10,
      select: {
        id: true,
        type: true,
        provider: true,
        prompt: true,
        status: true,
        creditsUsed: true,
        createdAt: true,
      },
    });

    return NextResponse.json({
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      username: user.username,
      role: user.role,
      credits,
      plan: user.subscription?.planType || 'Free',
      subscriptionStatus: user.subscription?.status || 'active',
      recentJobs,
    });
  } catch (e: any) {
    console.error('user/me', e);
    return NextResponse.json(
      { error: e?.message || 'خطأ في جلب بيانات المستخدم' },
      { status: 500 }
    );
  }
}
