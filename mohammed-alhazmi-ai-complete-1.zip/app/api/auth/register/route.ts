import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import bcrypt from 'bcrypt';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { firstName, lastName, username, email, phoneNumber, country, city, password, confirmPassword, avatarUrl } = body;

    if (password !== confirmPassword) {
      return NextResponse.json({ error: 'كلمات المرور غير متطابقة' }, { status: 400 });
    }

    const existingUser = await prisma.user.findFirst({
      where: { OR: [{ email }, { username }] }
    });

    if (existingUser) {
      return NextResponse.json({ error: 'البريد الإلكتروني أو اسم المستخدم مستخدم مسبقاً' }, { status: 400 });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = await prisma.user.create({
      data: {
        firstName, lastName, username, email, passwordHash: hashedPassword, phoneNumber, country, city, avatarUrl,
        subscription: {
          create: { planType: 'مجانية', monthlyLimit: 50, validUntil: new Date(new Date().setMonth(new Date().getMonth() + 1)), status: 'active' }
        },
        credits: { create: { balance: 10 } }
      }
    });

    return NextResponse.json({ message: 'تم إنشاء الحساب بنجاح', user: newUser }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'حدث خطأ أثناء تسجيل الحساب' }, { status: 500 });
  }
}