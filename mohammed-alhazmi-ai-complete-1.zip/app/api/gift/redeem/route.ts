import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

/**
 * POST /api/gift/redeem
 * Body: { code: string, userId: string }
 * When user enters gift code:
 * - Validates code (exists, not expired, uses left)
 * - Updates user subscription to the gift plan
 * - Adds creditsReward to wallet
 * - Increments usedCount
 */
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { code, userId, email } = body;

    if (!code || typeof code !== 'string') {
      return NextResponse.json({ error: 'يرجى إدخال كود الهدية' }, { status: 400 });
    }

    const normalized = code.toUpperCase().trim();

    // Find gift code
    const gift = await prisma.giftCode.findUnique({
      where: { code: normalized },
    });

    if (!gift) {
      return NextResponse.json({ error: 'كود الهدية غير صحيح' }, { status: 404 });
    }

    if (gift.expiresAt && new Date(gift.expiresAt) < new Date()) {
      return NextResponse.json({ error: 'انتهت صلاحية هذا الكود' }, { status: 400 });
    }

    if (gift.usedCount >= gift.maxUses) {
      return NextResponse.json({ error: 'تم استخدام هذا الكود بالكامل' }, { status: 400 });
    }

    // Resolve user
    let user = null;
    if (userId) {
      user = await prisma.user.findUnique({ where: { id: userId } });
    } else if (email) {
      user = await prisma.user.findUnique({ where: { email } });
    }

    if (!user) {
      return NextResponse.json(
        { error: 'المستخدم غير موجود. تأكد من تسجيل الدخول أو أن الحساب مربوط بقاعدة البيانات.' },
        { status: 404 }
      );
    }

    const validUntil = new Date();
    validUntil.setDate(validUntil.getDate() + (gift.durationDays || 30));

    // Upsert subscription
    await prisma.subscription.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        planType: gift.planType,
        monthlyLimit: gift.creditsReward || 200,
        status: 'active',
        validUntil,
      },
      update: {
        planType: gift.planType,
        monthlyLimit: gift.creditsReward || 200,
        status: 'active',
        validUntil,
      },
    });

    // Ensure wallet exists and add credits
    const wallet = await prisma.wallet.upsert({
      where: { userId: user.id },
      create: {
        userId: user.id,
        freeCredits: gift.creditsReward || 0,
        paidCredits: 0,
        referralCredits: 0,
      },
      update: {
        freeCredits: { increment: gift.creditsReward || 0 },
      },
    });

    // Log transaction
    await prisma.walletTransaction.create({
      data: {
        userId: user.id,
        type: 'gift',
        amount: gift.creditsReward || 0,
        balanceAfter: wallet.freeCredits + wallet.paidCredits + wallet.referralCredits,
        description: `تفعيل كود هدية: ${normalized}`,
        reference: gift.id,
      },
    });

    // Increment used count
    await prisma.giftCode.update({
      where: { id: gift.id },
      data: { usedCount: { increment: 1 } },
    });

    return NextResponse.json({
      message: 'تم تفعيل كود الهدية بنجاح 🎁',
      plan: gift.planType,
      creditsAdded: gift.creditsReward,
      validUntil,
    });
  } catch (error: any) {
    console.error('Redeem gift error:', error);
    return NextResponse.json(
      { error: error?.message || 'فشل تفعيل الكود' },
      { status: 500 }
    );
  }
}
