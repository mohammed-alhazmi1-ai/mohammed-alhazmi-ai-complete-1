import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { isOwnerEmail } from '@/lib/credits';

export async function GET() {
  try {
    const s = await prisma.setting.findUnique({ where: { key: 'maintenance' } });
    return NextResponse.json({ maintenance: s?.value === 'true' || s?.value === '1' });
  } catch {
    return NextResponse.json({ maintenance: false });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const email = (body.email || '').toLowerCase();
    if (!email || !(await isOwnerEmail(email))) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    }
    const value = body.enabled ? 'true' : 'false';
    await prisma.setting.upsert({
      where: { key: 'maintenance' },
      create: { key: 'maintenance', value },
      update: { value },
    });
    return NextResponse.json({ success: true, maintenance: body.enabled });
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
