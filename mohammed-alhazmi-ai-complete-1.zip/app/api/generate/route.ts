import { NextRequest, NextResponse } from 'next/server';
import {
  COST_PER_TEXT,
  deductCredits,
  ensureUserByEmail,
  getMaintenanceMode,
  totalCredits,
} from '@/lib/credits';
import { prisma } from '@/lib/prisma';
import { generateWithFallback } from '@/lib/ai/router';

export async function POST(req: NextRequest) {
  try {
    if (await getMaintenanceMode()) {
      return NextResponse.json(
        { error: 'المنصة في وضع الصيانة حالياً.' },
        { status: 503 }
      );
    }

    const body = await req.json();
    const {
      prompt,
      model,
      tone = 'احترافي',
      length = 'متوسط',
      email,
      provider: preferredProvider,
    } = body;

    if (!prompt?.trim()) {
      return NextResponse.json({ error: 'الرجاء إدخال نص الطلب.' }, { status: 400 });
    }
    if (!email) {
      return NextResponse.json({ error: 'يجب تسجيل الدخول.' }, { status: 401 });
    }

    const user = await ensureUserByEmail(String(email));
    const balance = totalCredits(user.wallet);

    let cost = COST_PER_TEXT;
    try {
      const sc = await prisma.serviceCost.findUnique({ where: { serviceKey: 'text_generate' } });
      if (sc?.isActive) cost = sc.creditsCost;
    } catch {
      /* default */
    }

    if (balance < cost) {
      return NextResponse.json(
        { error: `رصيد غير كافٍ (${balance}/${cost})`, credits: balance },
        { status: 402 }
      );
    }

    let pref = preferredProvider as string | undefined;
    const modelStr = String(model || '');
    if (!pref) {
      if (/gpt|openai/i.test(modelStr)) pref = 'openai';
      else if (/gemini|google/i.test(modelStr)) pref = 'gemini';
    }

    let preferredModel: string | undefined;
    if (/flash/i.test(modelStr)) preferredModel = 'gemini-1.5-flash';
    else if (/pro/i.test(modelStr) && /gemini/i.test(modelStr)) preferredModel = 'gemini-1.5-pro';
    else if (/4o-mini|4o mini/i.test(modelStr)) preferredModel = 'gpt-4o-mini';
    else if (/4o/i.test(modelStr)) preferredModel = 'gpt-4o';
    else if (/3\.5/i.test(modelStr)) preferredModel = 'gpt-3.5-turbo';

    const systemPrompt = `أنت مساعد ذكاء اصطناعي محترف.
نبرة النص: ${tone}.
حجم النص: ${length}.
الطلب: ${prompt}

أجب بشكل واضح ومنظم.`;

    const result = await generateWithFallback({
      prompt,
      systemPrompt,
      category: 'text',
      preferredProvider: pref,
      preferredModel,
    });

    const newBalance = await deductCredits(
      user.id,
      cost,
      `توليد — ${result.provider}/${result.model}`
    );

    try {
      await prisma.aiJob.create({
        data: {
          userId: user.id,
          provider: result.provider,
          model: result.model,
          type: 'text',
          prompt: prompt.slice(0, 2000),
          result: result.text.slice(0, 5000),
          status: 'completed',
          creditsUsed: cost,
          finishedAt: new Date(),
        },
      });
    } catch {
      /* ignore */
    }

    return NextResponse.json({
      result: result.text,
      model: result.model,
      provider: result.provider,
      usedFallback: result.usedFallback,
      attempts: result.attempts,
      creditsUsed: cost,
      creditsRemaining: newBalance,
      latencyMs: result.latencyMs,
    });
  } catch (error: any) {
    console.error('Generate error:', error);
    return NextResponse.json(
      { error: error?.message || 'حدث خطأ أثناء التوليد' },
      { status: 500 }
    );
  }
}
