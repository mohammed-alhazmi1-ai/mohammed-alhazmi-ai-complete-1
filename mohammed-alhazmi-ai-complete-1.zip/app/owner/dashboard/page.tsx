import Link from 'next/link';

const quickLinks = [
  { href: '/owner/analytics', title: 'التحليلات', icon: '📊', desc: 'Analytics' },
  { href: '/owner/providers', title: 'مزودو AI', icon: '🤖', desc: 'AI Providers' },
  { href: '/owner/api-keys', title: 'مفاتيح API', icon: '🔑', desc: 'API Keys' },
  { href: '/owner/users', title: 'المستخدمين', icon: '👥', desc: 'Users' },
  { href: '/owner/wallets', title: 'المحافظ', icon: '💰', desc: 'Wallets' },
  { href: '/owner/withdrawals', title: 'السحوبات', icon: '📤', desc: 'Withdrawals' },
  { href: '/owner/payments', title: 'المدفوعات', icon: '💳', desc: 'Payments' },
  { href: '/owner/gift-codes', title: 'أكواد الهدايا', icon: '🎁', desc: 'Gift Codes' },
  { href: '/owner/logs', title: 'السجلات', icon: '📜', desc: 'Logs' },
  { href: '/owner/settings', title: 'الإعدادات', icon: '⚙️', desc: 'Settings' },
  { href: '/owner/maintenance', title: 'الصيانة', icon: '🔧', desc: 'Maintenance' },
  { href: '/owner/backup', title: 'النسخ الاحتياطي', icon: '💾', desc: 'Backup' },
  { href: '/owner/mobile-app', title: 'تطبيق الموبايل', icon: '📱', desc: 'Mobile App' },
  { href: '/owner/marketplace', title: 'المتجر', icon: '🛒', desc: 'Marketplace' },
];

export default function OwnerDashboardPage() {
  return (
    <div className="space-y-8" dir="rtl">
      <div className="flex justify-between items-center pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl font-bold text-white">لوحة تحكم المالك 👑</h1>
          <p className="text-slate-400 text-xs mt-1">
            إدارة كاملة: مستخدمين · مزودين · محافظ · مدفوعات · تطبيق موبايل
          </p>
        </div>
        <Link
          href="/"
          className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-slate-300 text-xs hover:text-white"
        >
          الموقع
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'المستخدمون', value: '—', color: 'text-blue-400' },
          { label: 'الإيرادات', value: '$0', color: 'text-emerald-400' },
          { label: 'طلبات اليوم', value: '0', color: 'text-purple-400' },
          { label: 'أكواد نشطة', value: '—', color: 'text-amber-400' },
        ].map((s) => (
          <div key={s.label} className="rounded-2xl bg-slate-900 border border-slate-800 p-5">
            <p className={`text-2xl font-extrabold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-slate-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Quick links - all admin sections */}
      <div>
        <h2 className="text-sm font-bold text-slate-400 mb-4">أقسام لوحة الإدارة</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {quickLinks.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="rounded-2xl border border-slate-800 bg-slate-900 hover:border-blue-600/50 hover:bg-slate-900/80 p-4 transition group"
            >
              <span className="text-2xl">{l.icon}</span>
              <p className="font-bold text-white text-sm mt-2 group-hover:text-blue-300">{l.title}</p>
              <p className="text-[10px] text-slate-600 font-mono mt-0.5">{l.desc}</p>
            </Link>
          ))}
        </div>
      </div>

      {/* AI Providers quick panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-white">مزودو AI السريع 🤖</h3>
          <Link href="/owner/providers" className="text-xs text-blue-400 hover:underline">
            إدارة كاملة →
          </Link>
        </div>
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            { name: 'Google Gemini', status: 'جاهز للربط', ok: true },
            { name: 'OpenAI', status: 'بانتظار المفتاح', ok: false },
            { name: 'Anthropic Claude', status: 'بانتظار المفتاح', ok: false },
          ].map((p) => (
            <div key={p.name} className="rounded-xl bg-slate-950 border border-slate-800 p-4">
              <p className="font-bold text-white text-sm">{p.name}</p>
              <p className={`text-xs mt-1 ${p.ok ? 'text-emerald-400' : 'text-slate-500'}`}>
                {p.status}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Payment gateways summary */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-white">المحافظ 💰</h3>
          <Link href="/owner/wallets" className="text-xs text-blue-400 hover:underline">
            تفعيل البوابات →
          </Link>
        </div>
        <p className="text-xs text-slate-400">
          PayPal · Stripe · Binance Pay · Coinbase · Payoneer · Wise · USDT (TRC20/ERC20) · محافظ محلية
        </p>
      </div>
    </div>
  );
}
