'use client';
import { useEffect, useState } from 'react';
import OwnerPageShell from '@/components/owner/OwnerPageShell';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL || '',
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''
);

export default function MaintenancePage() {
  const [enabled, setEnabled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    fetch('/api/owner/maintenance')
      .then((r) => r.json())
      .then((d) => setEnabled(!!d.maintenance))
      .catch(() => {});
  }, []);

  const save = async () => {
    setLoading(true);
    setMsg('');
    const { data: { session } } = await supabase.auth.getSession();
    const email = session?.user?.email || '';
    try {
      const res = await fetch('/api/owner/maintenance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, enabled }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'فشل');
      setMsg(enabled ? 'تم تفعيل وضع الصيانة' : 'تم إيقاف وضع الصيانة');
    } catch (e: any) {
      setMsg(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <OwnerPageShell title="الصيانة 🔧" description="تعطيل التوليد مؤقتاً لجميع المستخدمين">
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 max-w-lg space-y-4">
        <label className="flex items-center justify-between gap-4">
          <span className="text-sm text-white">وضع الصيانة</span>
          <input
            type="checkbox"
            checked={enabled}
            onChange={(e) => setEnabled(e.target.checked)}
            className="w-5 h-5 accent-amber-500"
          />
        </label>
        <p className="text-xs text-slate-500">
          عند التفعيل: واجهة الموقع تبقى ظاهرة، لكن طلبات التوليد تُرفض برسالة صيانة.
        </p>
        <button
          onClick={save}
          disabled={loading}
          className="px-6 py-2.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white rounded-xl text-sm font-bold"
        >
          {loading ? '...' : 'حفظ'}
        </button>
        {msg && <p className="text-xs text-emerald-400">{msg}</p>}
      </div>
    </OwnerPageShell>
  );
}
