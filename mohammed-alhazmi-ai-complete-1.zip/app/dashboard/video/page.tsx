'use client';
import ServiceWorkspace from '@/components/dashboard/ServiceWorkspace';

export default function Page() {
  return <ServiceWorkspace service="video" />;
}
